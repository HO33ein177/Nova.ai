package com.example.bio.presentation.common.component.chat

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.GET
import com.example.bio.presentation.common.component.quiz.PdfListResponse
import com.example.bio.presentation.common.component.quiz.QuizRequest
import com.example.bio.presentation.common.component.quiz.QuizResponse
import com.example.bio.presentation.common.component.quiz.EvaluateRequest
import com.example.bio.presentation.common.component.quiz.EvaluateResponse

interface ApiService {

    @POST("chat")
    suspend fun sendTextMessage(@Body request: ChatRequest): Response<ChatResponse>

    @Multipart
    @POST("chat/audio")
    suspend fun sendAudioMessage(
        @Part("user_id") userId: RequestBody,
        @Part("conversation_id") conversationId: RequestBody,
        @Part audio: MultipartBody.Part
    ): Response<ChatResponse>

    @POST("generate/quiz")
    suspend fun generateQuiz(@Body request: QuizRequest): Response<QuizResponse>

    @POST("evaluate/answer")
    suspend fun evaluateAnswer(@Body request: EvaluateRequest): Response<EvaluateResponse>

    @GET("pdfs")
    suspend fun getPdfList(): Response<PdfListResponse>
}