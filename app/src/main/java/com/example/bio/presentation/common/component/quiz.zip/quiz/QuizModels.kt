package com.example.bio.presentation.common.component.quiz

data class QuizRequest(val pdf_filename: String)

data class QuizResponse(
    val topic: String,
    val questions: List<Question>,
    val answers: List<Answer>
)

data class Question(
    val id: Int,
    val text: String
)

data class Answer(
    val id: Int,
    val text: String
)

// مدل‌های مربوط به ارزیابی پاسخ
data class EvaluateRequest(
    val user_answer: String,
    val correct_answer: String
)

data class EvaluateResponse(
    val is_correct: Boolean,
    val similarity_score: Float
)