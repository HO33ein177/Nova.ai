package com.example.bio.presentation.common.component.quiz

import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.bio.presentation.common.component.chat.ApiService
import com.example.bio.presentation.common.component.quiz.EvaluateRequest
import com.example.bio.presentation.common.component.quiz.Question
import com.example.bio.presentation.common.component.quiz.QuizRequest
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

// برای مدیریت وضعیت‌های مختلف UI
sealed class QuizUiState {
    object Loading : QuizUiState()
    data class Success(val topic: String, val questions: List<Question>) : QuizUiState()
    data class Evaluating(val message: String) : QuizUiState()
    data class Result(val results: List<EvaluationResult>) : QuizUiState()
    data class Error(val message: String) : QuizUiState()
}

data class EvaluationResult(
    val question: Question,
    val userAnswer: String,
    val correctAnswer: String,
    val isCorrect: Boolean,
    val score: Float
)

@HiltViewModel
class QuizViewModel @Inject constructor(
    private val apiService: ApiService
) : ViewModel() {

    private val _uiState = MutableStateFlow<QuizUiState>(QuizUiState.Loading)
    val uiState = _uiState.asStateFlow()

    // نقشه برای نگهداری پاسخ‌های کاربر
    val userAnswers = mutableStateMapOf<Int, String>()
    private var correctAnswers = mapOf<Int, String>()

    fun loadQuiz(pdfFilename: String) {
        viewModelScope.launch {
            _uiState.value = QuizUiState.Loading
            try {
                val response = apiService.generateQuiz(QuizRequest(pdf_filename = pdfFilename))
                if (response.isSuccessful && response.body() != null) {
                    val quiz = response.body()!!
                    correctAnswers = quiz.answers.associateBy({ it.id }, { it.text })
                    quiz.questions.forEach { userAnswers[it.id] = "" } // مقداردهی اولیه پاسخ‌ها
                    _uiState.value = QuizUiState.Success(quiz.topic, quiz.questions)
                } else {
                    _uiState.value = QuizUiState.Error("Failed to load quiz: ${response.message()}")
                }
            } catch (e: Exception) {
                _uiState.value = QuizUiState.Error("Network error: ${e.localizedMessage}")
            }
        }
    }

    fun submitQuiz() {
        viewModelScope.launch {
            val totalQuestions = correctAnswers.size
            val evaluationResults = mutableListOf<EvaluationResult>()

            for ((index, questionId) in correctAnswers.keys.withIndex()) {
                _uiState.value = QuizUiState.Evaluating("Evaluating question ${index + 1} of $totalQuestions...")
                val userAnswer = userAnswers[questionId] ?: ""
                val correctAnswer = correctAnswers[questionId] ?: ""

                try {
                    val response = apiService.evaluateAnswer(EvaluateRequest(user_answer = userAnswer, correct_answer = correctAnswer))
                    if (response.isSuccessful && response.body() != null) {
                        val eval = response.body()!!
                        val question = (_uiState.value as? QuizUiState.Success)?.questions?.find { it.id == questionId }
                        if (question != null) {
                            evaluationResults.add(
                                EvaluationResult(question, userAnswer, correctAnswer, eval.is_correct, eval.similarity_score)
                            )
                        }
                    }
                } catch (e: Exception) {
                    // مدیریت خطا برای یک سوال
                }
            }
            _uiState.value = QuizUiState.Result(evaluationResults)
        }
    }
}